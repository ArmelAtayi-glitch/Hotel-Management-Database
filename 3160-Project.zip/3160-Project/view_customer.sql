CREATE VIEW `view_customer` AS
SELECT *
FROM Customer;